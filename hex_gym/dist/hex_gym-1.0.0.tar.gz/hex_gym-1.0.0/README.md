<h1>Hexapod OpenAi Gym environment</h1>
<p>Uses an urdf file to import the pod in an GUI environment</p>
* Used fuzzy logic for the reward.<br>
* The reward function was calculated as the ratio of other observations with the displacement in x direction.<br>
<i>author: unicorn-io